from django.apps import AppConfig


class FstappConfig(AppConfig):
    name = 'fstapp'
